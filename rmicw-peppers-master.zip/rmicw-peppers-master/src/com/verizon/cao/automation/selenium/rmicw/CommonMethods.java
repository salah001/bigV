package com.verizon.cao.automation.selenium.rmicw;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.verizon.cao.automation.selenium.base.BaseFramework;
import com.verizon.cao.automation.selenium.pojo.DataSheet;

import com.verizon.cao.automation.selenium.pojo.PassedFailedSteps;

import com.verizon.cao.automation.selenium.pojo.TestAction;
import com.verizon.cao.automation.selenium.run.DefaultTestExcelDriven;
import com.verizon.cao.automation.selenium.util.CustomMethodReportUtil;

import com.verizon.cao.automation.selenium.util.Keywords;
import com.verizon.cao.automation.selenium.util.UpdateEnvDetailInDataSheet;

public class CommonMethods extends CustomMethodReportUtil {

	/**

	 * This a sample custom method. All the custom methods needs to be followed in the same template.Classname.

	 * Method name will be the keyword for the particular method(eg:SampleCustomClass.sampleCustomMethod)

	 * @param driver

	 * @param testId

	 * @param testCaseId

	 * @param TestAction

	 * @param test

	 * @param steps

	 * @param testCase

	 * @return

	 * @throws IOException

	 */

	public static int Synctime=90;

	Keywords KeywordsObj= new Keywords();
	/************************************************************************************
	 * Function Name 	: sampleCustomMethod
	 * Applicable Class	: txt, elm
	 * Creation date 	: Feb 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	

	public PassedFailedSteps sampleCustomMethod(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps,DataSheet testCase) throws IOException{
		try{
			// You can write your custom logics here
			//Below is the sample code
			System.out.println(testCase.getJSON());
			System.out.println("Room ID: "+testCase.getJSON().get("roomId"));
			new Keywords().manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator());
			System.out.println("entered custom method");
			//Logger for the particular custom method
			report(Status.PASS, "Expected result", "Actual Result", testId, testCaseId, TestAction, test, steps);
		}catch(Exception ey)
		{

			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Actual Result "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}


	public PassedFailedSteps SwitchToFrame(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{

			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			WebElement we = wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())));
			driver.switchTo().frame(we);
			report(Status.PASS, "Expected result", "Switched to Frame", testId, testCaseId, TestAction, test, steps);
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Did not Switch to the Frame"+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: verifyText
	 * Applicable Class	: txt, elm
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	public PassedFailedSteps verifyText(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{   
			String b,actualText;
			String key = TestAction.getInputData();
			boolean blnMultiple = false,blnfound = false;
			if(key.contains("~"))
			{
				blnMultiple = true;
			}
			if(key.equalsIgnoreCase("seempty"))
			{
				key = "";
			}
			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())));
			WebElement element = driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
			if(element.getAttribute("value") == null)
			{
				b = "";
			}
			else
			{
				b=element.getAttribute("value");
			}
			if(element.getText() == null)
			{
				actualText= "";
			}
			else
			{
				actualText = element.getText();
			}
			b = b.replaceAll("\\n","").replace(" ","");
			actualText = actualText.replaceAll("\\n","").replace(" ","");
			if(blnMultiple)
			{
				String arrkey[] = key.split("~");
				for(int i = 0;i<arrkey.length;i++)
				{
					arrkey[i] = arrkey[i].replaceAll("\\n","").replace(" ","").toLowerCase();
					if(actualText.toLowerCase().contains(arrkey[i]) || b.toLowerCase().contains(arrkey[i]))
					{
						blnfound = true;
					}
					else
					{
						report(Status.FAIL, "Expected result", "Verify text is not equal with given text", testId, testCaseId, TestAction, test, steps);
						return pfSteps;
					}
				}
			}
			else
			{
				String key1=key = key.replaceAll("\\n","").replace(" ","");
				if (actualText.equalsIgnoreCase(key1) || b.equalsIgnoreCase(key)){
					blnfound =true;
				}
			} 
			if (blnfound){
				report(Status.PASS, "Expected result", "Verify text is equal with given text", testId, testCaseId, TestAction, test, steps);
			}else {
				report(Status.FAIL, "Expected result", "Verify text is not equal with given text", testId, testCaseId, TestAction, test, steps);
			}
		}
		catch(Exception err)
		{
			report(Status.FAIL, "Expected result", "Verify text is not equal with given text\n Error Message"+err.getMessage(), testId, testCaseId, TestAction, test, steps);
			return pfSteps;
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: WaitUntilElementVisible
	 * Applicable Class	: All
	 * Creation date 	: Feb 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/
	public PassedFailedSteps WaitUntilElementVisible(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			WebDriverWait wait = new WebDriverWait(driver, 300); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			//WebElement we=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())); 

			// Check whether input field is blank
			report(Status.PASS, "Expected result", "Element Visible", testId, testCaseId, TestAction, test, steps);

		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Element not Visible\n Error Message--->"+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: verifyAttribute
	 * Applicable Class	: All
	 * Creation date 	: Feb 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/
	public PassedFailedSteps verifyAttribute(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			String strattribute,strValue,attributevalue;
			strattribute=strValue=attributevalue="";
			String input = TestAction.getInputData();
			if(input.contains("~"))
			{
				strattribute = input.split("~")[0];
				strValue = input.split("~")[1];
			}
			WebDriverWait wait = new WebDriverWait(driver, 20); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			attributevalue = driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())).getAttribute(strattribute);
			if(attributevalue.toLowerCase().contains(strValue.toLowerCase()))
			{
				report(Status.PASS, "Verify Attribute", "The attribute verification is succesful", testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Verify Attribute", "The attribute verification is not succesful", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception e)
		{
			report(Status.FAIL, "Verify Attribute", "The attribute verification is not succesful\n Error Message--->"+e.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/*************************************************************************************
	 * Function Name 	: isDisplayed
	 * Applicable Class	: All
	 * Creation date 	: Feb 2017
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	public PassedFailedSteps isDisplayed(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			WebDriverWait wait = new WebDriverWait(driver, Synctime); 
			String TrueFalse = TestAction.getInputData();
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			WebElement element=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())); 
			if (String.valueOf(element.isDisplayed()).equalsIgnoreCase(TrueFalse))
			{
				report(Status.PASS, "Expected result", "The element is displayed is verified succesfully", testId, testCaseId, TestAction, test, steps); 
				return pfSteps;
			}
			else
			{
				if(TrueFalse.equalsIgnoreCase("true"))
				{
					int x = element.getLocation().x;
					int y = element.getLocation().y;
					if(x>0 && y>0)
					{
						report(Status.PASS, "Expected result", "The element is displayed is verified succesfully", testId, testCaseId, TestAction, test, steps); 
						return pfSteps;
					}
					else
					{
						report(Status.FAIL, "Expected result", "The element is not displayed in the page", testId, testCaseId, TestAction, test, steps); 
						return pfSteps;
					}
				}
				else
				{
					report(Status.FAIL, "Expected result", "The element is not displayed in the page", testId, testCaseId, TestAction, test, steps); 
					return pfSteps;
				}
			}
		}catch(Exception err){
			System.out.println(err.getMessage());
			report(Status.FAIL, "Expected result", "The element is not displayed in the page\n Error Message --->"+err.getMessage(), testId, testCaseId, TestAction, test, steps); 
			return pfSteps;
		}
	}
	/************************************************************************************
	 * Function Name 	: UpdateTexttoParameter
	 * Applicable Class	: txt, elm
	 * Creation date 	: Feb 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	public PassedFailedSteps UpdateTexttoParameter(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{   
			String b,actualText,testcaseid,strparam;
			String key = TestAction.getInputData();
			if(key.contains("~"))
			{
				testcaseid = key.split("~")[0];
				strparam = key.split("~")[1];
			}else
			{
				testcaseid = key;
				strparam = "";
			}
			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())));
			WebElement element = driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
			if(element.getAttribute("value") == null)
			{
				b = "";
			}
			else
			{
				b=element.getAttribute("value");
			}
			if(element.getText() == null)
			{
				actualText= "";
			}
			else
			{
				actualText = element.getText();
			}
			if(strparam.equalsIgnoreCase("numbersonly"))
			{
				b = b.replaceAll("\\n","").replace(" ","").replaceAll("//D+", "");
				actualText = actualText.replaceAll("\\n","").replace(" ","").replaceAll("//D+", "");
			}else
			{
				b = b.replaceAll("\\n","").replace(" ","");
				actualText = actualText.replaceAll("\\n","").replace(" ","");
			}
			if(b != "")
			{
				for(DataSheet dataSheet : BaseFramework.dataSheetList){ 
					if(testcaseid.equals(dataSheet.getTestCaseId())){
						if(dataSheet.getParams().equals("")){
							dataSheet.setParams(b);
							System.out.println("updateParam : "+dataSheet.getParams());
							break;
						}else{
							dataSheet.setParams(dataSheet.getParams()+"~"+b);
							System.out.println("updateParam : "+dataSheet.getParams());
							break;
						}
					}
				}
				report(Status.PASS, "Expected result", "The get text or Claim or project Number are  "+b, testId, testCaseId, TestAction, test, steps);
			}else
			{
				for(DataSheet dataSheet : BaseFramework.dataSheetList){ 
					if(testcaseid.equals(dataSheet.getTestCaseId())){
						if(dataSheet.getParams().equals("")){
							dataSheet.setParams(actualText);
							System.out.println("updateParam : "+dataSheet.getParams());
							break;
						}else{
							dataSheet.setParams(dataSheet.getParams()+"~"+actualText);
							System.out.println("updateParam : "+dataSheet.getParams());
							break;
						}
					}
				}
				report(Status.PASS, "Expected result", "The get text or Claim or project Number are  "+b, testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception e){
			report(Status.FAIL, "Expected result", "The element is not found in the page \n Error Message --->"+e.getMessage(), testId, testCaseId, TestAction, test, steps); 
			return pfSteps;
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: isAlertPresent
	 * Applicable Class	: alert
	 * Creation date 	: Feb 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	public PassedFailedSteps isAlertPresent(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{

			WebDriverWait wait = new WebDriverWait(driver, 300 /*timeout in seconds*/);
			if(wait.until(ExpectedConditions.alertIsPresent())==null)
				System.out.println("alert was not present");
			else
				System.out.println("alert was present");
			report(Status.PASS, "Expected result", "alert was present", testId, testCaseId, TestAction, test, steps);

		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "alert was not present", testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: scrollPageToEnd
	 * Applicable Class	: pge
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * @throws Exception 
	 * *********************************************************************************/		
	public PassedFailedSteps scrollPageToEnd(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try {
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("window.scrollTo(0, document.body.scrollHeight)");
			report(Status.PASS, "Expected result", "Scroll to end is succesfully", testId, testCaseId, TestAction, test, steps); 
			return pfSteps;
		} catch (Exception e) {
			report(Status.FAIL, "Expected result", "Scroll to end of the page is not successfull \n Error Message --->"+e.getMessage(), testId, testCaseId, TestAction, test, steps); 
			return pfSteps;
		}
	}
	/************************************************************************************
	 * Function Name 	: scrollPageToEnd
	 * Applicable Class	: pge
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * @return 
	 * @throws Exception 
	 * *********************************************************************************/		
	public PassedFailedSteps verifyCurrentUrl(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try {
			String currentURL = driver.getCurrentUrl();
			if(!currentURL.toLowerCase().contains("fault.aspx"))
			{
				report(Status.PASS, "Expected result", "Page Navigation is working as Expected", testId, testCaseId, TestAction, test, steps); 
				return pfSteps;
			}else
			{
				report(Status.FAIL, "Expected result", "The Page is navigated to Page not found", testId, testCaseId, TestAction, test, steps); 
				return pfSteps;
			}
		} catch (Exception e) {
			report(Status.FAIL, "Expected result", "Scroll to end of the page is not successfull \n Error Message --->"+e.getMessage(), testId, testCaseId, TestAction, test, steps); 
			return pfSteps;
		}
	}
	/************************************************************************************
	 * Function Name 	: datePicker
	 * Applicable Class	: element
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * @throws Exception 
	 * *********************************************************************************/	
	public PassedFailedSteps datePicker(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{

		try{
			String day,month,year;
			day=month=year="";
			if(TestAction.getInputData().toLowerCase().contains("yyyy"))
			{
				Date date = new Date();
				SimpleDateFormat sdf;
				sdf = new SimpleDateFormat("d-MMMM-yyyy");
				String today = sdf.format(date);
				day = today.split("-")[0];
				month = today.split("-")[1];
				year = today.split("-")[2];
			}else
			{
				day = TestAction.getInputData().split("-")[0];
				month = TestAction.getInputData().split("-")[1];
				year = TestAction.getInputData().split("-")[2];
			}
			
			System.out.println("date and month and year" +day+month+year);
			driver.findElement(By.xpath(TestAction.getLocator())).click();
			Thread.sleep(8000);
			driver.findElement(By.xpath("//div[@id='monthSelect']")).click();
			Thread.sleep(5000);
			String Monthxpath = "//div[@id='monthDropDown']/div[text()='"+month+"']";
			driver.findElement(By.xpath(Monthxpath)).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("(//div[@class='selectBox'])[2]")).click();
			//Fixed the issue for previous years selection if year is not visible in calendar by Sudhakar Botu on 26/03/2019
			String obj="//div[@id='yearDropDown']";
			List<WebElement> elements = driver.findElements(By.xpath(obj));
			Iterator<WebElement> iter = elements.iterator();
			while(iter.hasNext()) {
			    WebElement we = iter.next();
			    if(we.getText().contains(year)) {
			    	we.click();
			    	Thread.sleep(5000);
			    	break;
			    }
			   else
			    {
				driver.findElement(By.xpath("//*[@id='yearDropDown']/div[1]")).click();
			    }
			}
			driver.findElement(By.xpath("//div[@id='yearDropDown']/div[text()='"+year+"']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//td[@class='calendar_week_column']/../td[text()='"+day+"'  and not(@class='calendar_week_column')]")).click();
			Thread.sleep(5000);
			report(Status.PASS, "Calendar", "Date picker is successful ", testId, testCaseId, TestAction, test, steps);
		}catch(Exception ey)
		{
			report(Status.FAIL, "Calendar", "Date picker is not successful ", testId, testCaseId, TestAction, test, steps);

		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: SelectTableValuesAccountinfo
	 * Applicable Class	: list
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	@SuppressWarnings("static-access")
	public PassedFailedSteps SelectTableValuesAccountinfo(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			WebElement we=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
			Select select = new Select(we);
			List<WebElement> items = select.getOptions();
			String textdata = "~";
			for(int j=1;j<items.size();j++)
			{
				textdata+= items.get(j).getText()+"~";
			}
			System.out.println(textdata);
			String strSelectableval [] = textdata.split("~");
			boolean blnverify = false;
			for(int i=1;i<items.size();i++)
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
				WebElement we1=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
				Select select1 = new Select(we1);
				select1.selectByIndex(i);
				Thread.sleep(3000);
				String currentURL = driver.getCurrentUrl();
				if(!currentURL.toLowerCase().contains("fault.aspx"))
				{
					report(Status.PASS, "Expected result", "Page Navigation is working as Expected", testId, testCaseId, TestAction, test, steps); 
					blnverify = true;
				}else
				{
					report(Status.FAIL, "Expected result", "The Page is navigated to Page not found", testId, testCaseId, TestAction, test, steps); 
					blnverify = false;
				}
				WebDriverWait wait1 = new WebDriverWait(driver, 300);
				wait1.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString("xpath", "//table[contains(@id,'gvAcctStatus')]"))); 
				DataSheet datasheet = new DataSheet();
				BaseFramework baseframework = new BaseFramework();
				Date date = new Date();
				SimpleDateFormat sdf;
				sdf = new SimpleDateFormat("ddMMYYYhhmmss");
				String today = sdf.format(date);
				String location=baseframework.screenshot(driver,datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - "+today);
				if(UpdateEnvDetailInDataSheet.config.getProperty("SELENIUM_GRID").equalsIgnoreCase("local")){
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(System.getProperty("user.dir")+ "\\Screenshots\\Screenshot"+ location + ".png").build());
					}
				}else{
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}
				}
				blnverify = true;
				//passedSteps.add(datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - ");
			}
			if(blnverify)
			{
				report(Status.PASS, "Expected result", "Select Table Iteration with all the values are succesful", testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Expected result", "Element does not exists  in the dropdown", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Element does not exists in the dropdown "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: SelectTableIRDatainfo
	 * Applicable Class	: list
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	@SuppressWarnings("static-access")
	public PassedFailedSteps SelectTableIRDatainfo(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			WebElement we=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
			Select select = new Select(we);
			List<WebElement> items = select.getOptions();
			String textdata = "~";
			for(int j=1;j<items.size();j++)
			{
				textdata+= items.get(j).getText()+"~";
			}
			System.out.println(textdata);
			String strSelectableval [] = textdata.split("~");
			boolean blnverify = false;
			for(int i=1;i<items.size();i++)
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
				WebElement we1=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
				Select select1 = new Select(we1);
				select1.selectByIndex(i);
				Thread.sleep(3000);
				driver.findElement(By.xpath("//input[contains(@id,'CPContent_btnFetchData')]")).click();
				//			WebDriverWait wait1 = new WebDriverWait(driver, 300);
				//			wait1.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString("xpath", "//table[contains(@id,'gvAcctStatus')]"))); 
				Thread.sleep(7000);
				DataSheet datasheet = new DataSheet();
				BaseFramework baseframework = new BaseFramework();
				Date date = new Date();
				SimpleDateFormat sdf;
				sdf = new SimpleDateFormat("ddMMYYYhhmmss");
				String today = sdf.format(date);
				String location=baseframework.screenshot(driver,datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - "+today);
				if(UpdateEnvDetailInDataSheet.config.getProperty("SELENIUM_GRID").equalsIgnoreCase("local")){
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(System.getProperty("user.dir")+ "\\Screenshots\\Screenshot"+ location + ".png").build());
					}
				}else{
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}
				}
				blnverify = true;
				//passedSteps.add(datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - ");
			}
			if(blnverify)
			{
				report(Status.PASS, "Expected result", "Select Table Iteration with all the values are succesful", testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Expected result", "Element does not exists  in the dropdown", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Element does not exists in the dropdown "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: organizationReqCap
	 * Applicable Class	: list
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	@SuppressWarnings("static-access")
	public PassedFailedSteps organizationReqCap(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			Thread.sleep(2000);
			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			WebElement we=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
			Select select = new Select(we);
			List<WebElement> items = select.getOptions();
			String textdata = "~";
			for(int j=1;j<items.size();j++)
			{
				textdata+= items.get(j).getText()+"~";
			}
			System.out.println(textdata);
			String strSelectableval [] = textdata.split("~");
			boolean blnverify = false;
			for(int i=1;i<items.size();i++)
			{
				wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
				WebElement we1=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
				Select select1 = new Select(we1);
				select1.selectByIndex(i);
				Thread.sleep(3000);
				WebDriverWait wait1 = new WebDriverWait(driver, 300);
				wait1.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString("xpath", "//table[contains(@id,'CPContent_gvCaplimit')]"))); 
				Thread.sleep(7000);
				DataSheet datasheet = new DataSheet();
				BaseFramework baseframework = new BaseFramework();
				Date date = new Date();
				SimpleDateFormat sdf;
				sdf = new SimpleDateFormat("ddMMYYYhhmmss");
				String today = sdf.format(date);
				String location=baseframework.screenshot(driver,datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - "+today);
				if(UpdateEnvDetailInDataSheet.config.getProperty("SELENIUM_GRID").equalsIgnoreCase("local")){
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(System.getProperty("user.dir")+ "\\Screenshots\\Screenshot"+ location + ".png").build());
					}
				}else{
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								+ " <h4><font  size=\"4\" color=\"red\">"+strSelectableval[i]+"</h4></font>",MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}
				}
				blnverify = true;
				//passedSteps.add(datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - ");
			}
			if(blnverify)
			{
				report(Status.PASS, "Expected result", "Select Table Iteration with all the values are succesful", testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Expected result", "Element does not exists  in the dropdown", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Element does not exists in the dropdown "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: rmicwdashboard
	 * Applicable Class	: list
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	@SuppressWarnings("static-access")
	public PassedFailedSteps rmicwdashboard(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			boolean blnverify = false;
			List<WebElement> we=driver.findElements(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()));
			for(int i=0;i<we.size();i++)
			{
				String xpath = TestAction.getLocator()+"[1]";
				WebElement we1=driver.findElement(KeywordsObj.manipulateLocatorString("xpath", xpath));
				int xaxis = we1.getLocation().getX();
				int yaxis = we1.getLocation().getY();
				yaxis = yaxis+200;
				System.out.println(xaxis);
				System.out.println(yaxis);
				we1.click();
				((JavascriptExecutor) driver).executeScript("scroll("+xaxis+", "+yaxis+");");
				Thread.sleep(3000);
				String currentURL = driver.getCurrentUrl();
				if(!currentURL.toLowerCase().contains("fault.aspx"))
				{
					report(Status.PASS, "Expected result", "Data is displaying correctly with out deviation", testId, testCaseId, TestAction, test, steps); 
					blnverify = true;
				}else
				{
					report(Status.FAIL, "Expected result", "Some error is occured the Page is navigated to Page not found", testId, testCaseId, TestAction, test, steps); 
					blnverify = false;
				}
				DataSheet datasheet = new DataSheet();
				BaseFramework baseframework = new BaseFramework();
				Date date = new Date();
				SimpleDateFormat sdf;
				sdf = new SimpleDateFormat("ddMMYYYhhmmss");
				String today = sdf.format(date);
				String location=baseframework.screenshot(driver,datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - "+today);
				if(UpdateEnvDetailInDataSheet.config.getProperty("SELENIUM_GRID").equalsIgnoreCase("local")){
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								,MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								,MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								,MediaEntityBuilder.createScreenCaptureFromPath(System.getProperty("user.dir")+ "\\Screenshots\\Screenshot"+ location + ".png").build());
					}
				}else{
					if(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH").length()>1){
						test.log(Status.PASS, TestAction.getDescription()
								,MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_VIRTUALPATH")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}else{
						test.log(Status.PASS, TestAction.getDescription()
								,MediaEntityBuilder.createScreenCaptureFromPath(UpdateEnvDetailInDataSheet.config.getProperty("SCREENSHOT_DRIVE")
										+ "/"+UpdateEnvDetailInDataSheet.config.getProperty("APPLICATION_NAME")+"/"+BaseFramework.currentDate+"/" + location + ".png").build());
					}
				}
				blnverify = true;
				//passedSteps.add(datasheet.getTestID() + " - "+datasheet.getTestCaseId() + " - "+ TestAction.getTestSID()+ " - "+ TestAction.getDescription()+ " - Passed - ");
			}
			if(blnverify)
			{
				report(Status.PASS, "Expected result", "Select Table Iteration with all the values are succesful", testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Expected result", "Element does not exists  in the dropdown", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Element does not exists in the dropdown "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: clearTextSendkeys
	 * Applicable Class	: text
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	public PassedFailedSteps clearTextSendkeys(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			System.out.println("into my clearText method " + "\n"); 
			WebDriverWait wait = new WebDriverWait(driver, Synctime); 
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator()))); 
			WebElement we=driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), TestAction.getLocator())); 
			//fnHighlightMe(driver,we); 
			we.click();
			//Thread.sleep(1000);
			we.sendKeys(Keys.CONTROL + "a");
			we.sendKeys(Keys.DELETE); 
			we.sendKeys(TestAction.getInputData());
			System.out.println("into my clearText last method " + "\n");
			report(Status.PASS, "Expected result", "Default Data cleared and Input Data is Entered Successfully", testId, testCaseId, TestAction, test, steps);

		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Default Data is not cleared and Input Data is not Entered Successfully", testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: switchWindow
	 * Applicable Class	: Windows
	 * Creation date 	: Mar 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/	
	public PassedFailedSteps switchWindow(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{
		try{
			String parent=driver.getWindowHandle();
			String inputdata = TestAction.getInputData();
			for (String handle : driver.getWindowHandles())
			{

				driver.switchTo().window(handle);
				String Currtitle = driver.getTitle();
				if(Currtitle.equalsIgnoreCase(inputdata))
				{
					driver.close();
				}
			}
			driver.switchTo().window(parent);
			report(Status.PASS, "Expected result", "Switch to parent window is succesful", testId, testCaseId, TestAction, test, steps);
			return pfSteps;
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Switch to default window is not successful", testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: MenuNavigation
	 * Applicable Class	: Menus
	 * Creation date 	: Feb 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/
	public PassedFailedSteps MenuNavigation(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{

		try{
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			String firstnav = "",secondnav = "";
			String input=TestAction.getInputData();
			String arrMenu[] = null;
			boolean blnverify = false;
			if(TestAction.getInputData().contains("~"))
			{
				arrMenu = input.split("~");
				if(arrMenu.length==2)
				{
					firstnav = arrMenu[0];
					secondnav = arrMenu[1];
				}else
				{
					firstnav = arrMenu[0];
				}
			}else
			{
				firstnav = input;
			}
			WebDriverWait wait = new WebDriverWait(driver, Synctime);
			wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), "//span[text()='"+firstnav+"']")));
			WebElement we = driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), "//span[text()='"+firstnav+"']"));
			Actions actions = new Actions(driver);
			actions.moveToElement(we).perform();
			if(arrMenu.length==1|| arrMenu==null)
			{
				jse.executeScript("arguments[0].focus();",we);
				Thread.sleep(2000);
				jse.executeScript("arguments[0].click();",we);
				blnverify = true;
				Thread.sleep(10000);
			}
			//clicking level2 menu
			if(!secondnav.equals(""))
			{
				WebElement we1 = null;
				wait.until(ExpectedConditions.visibilityOfElementLocated(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), "//span[text()='"+secondnav+"']")));
				we1 = driver.findElement(KeywordsObj.manipulateLocatorString(TestAction.getLocatorType(), "//span[text()='"+secondnav+"']"));
				actions.moveToElement(we1).perform();
				jse.executeScript("arguments[0].focus();",we1);
				jse.executeScript("arguments[0].click();",we1);
				blnverify = true;
			}
			if(blnverify)
			{
				report(Status.PASS, "Expected result", "Menu Navigation is succesfull", testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Expected result", "Menu Navigation is not succesfull", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Menu Navigation is not succesfull "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	/************************************************************************************
	 * Function Name 	: accountDBSearch
	 * Applicable Class	: Menus
	 * Creation date 	: June 2018
	 * Author			: Yogeeswar
	 * Revision			: None
	 * *********************************************************************************/
	@SuppressWarnings({ "resource", "unused" })
	public PassedFailedSteps accountDBSearch(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{

		try{
			int rowNumber = 0;
			//Row row;
			String strinput,sqlquery = "";
			Properties prop = new Properties();
			String propfilepath = System.getProperty("user.dir")+"/src/com/verizon/cao/automation/selenium/properties";
			FileInputStream input = new FileInputStream(propfilepath+"/config.properties"); 
			prop.load(input);
			strinput = TestAction.getInputData();
			if(strinput!="")
			{
				sqlquery = strinput;
			}else
			{
				String filepath = prop.getProperty("EXCEL_FILE_PATH");
				File file = new File(System.getProperty("user.dir")+filepath);
				//Create an object of FileInputStream class to read excel file
				FileInputStream inputStream = new FileInputStream(file);
				XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
				XSSFSheet sheet = workbook.getSheet("SQLQuries");
				int lastrownumber= sheet.getLastRowNum()+1;
				for(int i =1;i<=lastrownumber;i++)
				{
					String cellvale = sheet.getRow(i).getCell(0).getStringCellValue();
					if(cellvale.equalsIgnoreCase(testCaseId))
					{
						rowNumber = i;
						break;
					}
				}
				sqlquery = sheet.getRow(rowNumber).getCell(1).getStringCellValue();
			}
			String strAccountNbr="";
			boolean blnverify = false;
			//String strinput = TestAction.getInputData();
			String userName = prop.getProperty("DBUSERNAME");
			String password = prop.getProperty("DBPASS");
			String url = "jdbc:sqlserver:"+prop.getProperty("DBSERVER")+";databaseName=RMWvision";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			Connection con = DriverManager.getConnection(url,userName,password);
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery(sqlquery);
			while(rs.next())  
			{
				strAccountNbr = rs.getString(1);
				blnverify = true;
				break;
			}
			for(DataSheet dataSheet : BaseFramework.dataSheetList){ 
				if(testCaseId.equals(dataSheet.getTestCaseId())){
					if(dataSheet.getParams().equals("")){
						dataSheet.setParams(strAccountNbr);
						System.out.println("updateParam : "+dataSheet.getParams());
						break;
					}else{
						dataSheet.setParams(dataSheet.getParams()+"~"+strAccountNbr);
						System.out.println("updateParam : "+dataSheet.getParams());
						break;
					}
				}
			}
			rs.close();
			if(blnverify)
			{
				report(Status.PASS, "Expected result", "Account Number is fetched from the DB "+strAccountNbr, testId, testCaseId, TestAction, test, steps);
			}else
			{
				report(Status.FAIL, "Expected result", "Account Number id not extracted from the DB", testId, testCaseId, TestAction, test, steps);
			}
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Account fetch from DB is not succesfull "+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
}
