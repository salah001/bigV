package com.verizon.cao.automation.selenium.rmicw;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.verizon.cao.automation.selenium.base.BaseFramework;
import com.verizon.cao.automation.selenium.pojo.DataSheet;
import com.verizon.cao.automation.selenium.pojo.PassedFailedSteps;
import com.verizon.cao.automation.selenium.pojo.TestAction;
import com.verizon.cao.automation.selenium.util.CustomMethodReportUtil;
import com.verizon.cao.automation.selenium.util.DeCrypto;
import com.verizon.cao.automation.selenium.util.Keywords;
import com.verizon.cao.automation.selenium.util.UpdateEnvDetailInDataSheet;

public class LoginPage extends CustomMethodReportUtil {

	/**
	* This a sample custom method. All the custom methods needs to be followed in the same template.Classname.
	* Method name will be the keyword for the particular method(eg:SampleCustomClass.sampleCustomMethod)
	* @param driver
	* @param testId
	* @param testCaseId
	* @param TestAction
	* @param test
	* @param steps
	* @param testCase
	* @return
	* @throws IOException
	*/
	public static int Synctime=60;
	public PassedFailedSteps Login(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{

	try{
		String username = "",password = "";
		System.out.println("Into Login method");
		String input=TestAction.getInputData();
		if(input.toLowerCase().contains("~"))
		{
			username = input.split("~")[0];
			password = input.split("~")[1];
		}else
		{
			username = UpdateEnvDetailInDataSheet.config.getProperty("USERID");
			password = UpdateEnvDetailInDataSheet.config.getProperty("PASSWORD");
		}
		driver.get(UpdateEnvDetailInDataSheet.config.getProperty("URL"));
		report(Status.PASS, "Expected result", "<b>URL</b> : "+UpdateEnvDetailInDataSheet.config.getProperty("URL"), testId, testCaseId, TestAction, test, steps);
		//Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, Synctime);
		
		/* try {
			driver.navigate().to("javascript:document.getElementById('overridelink').click()");	
		}
		catch (Exception e){
			
		} */
		
		
		WebElement UserIDElement = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("LOGIN_TXT_USERNAME")))));
		//fnHighlightMe(driver,UserIDElement);
		UserIDElement.sendKeys(username);
		//Test.log(Status.PASS, "User ID Entered Successfully");
		//report(Status.PASS, "Expected result", username, testId, testCaseId, TestAction, test, steps);
		
		WebElement PasswordElement = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("LOGIN_TXT_PASSWORD")))));
		//fnHighlightMe(driver,PasswordElement);
		//PasswordElement.sendKeys(new DeCrypto().deCoder(UpdateEnvDetailInDataSheet.config.getProperty("PASSWORD")));
		PasswordElement.sendKeys(password);
		//report(Status.PASS, "Expected result", password, testId, testCaseId, TestAction, test, steps);
						
		//Test.log(Status.PASS, "Password Entered Successfully");
		
		WebElement SignonElement = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("LOGIN_BTN_SIGNON")))));	
		//fnHighlightMe(driver,SignonElement);
		SignonElement.click();
		//WebDriverWait wait = new WebDriverWait(driver, 300 /*timeout in seconds*/);
		wait.until(ExpectedConditions.alertIsPresent());
		Alert alert  = driver.switchTo().alert();
		alert.accept();
		WebDriverWait waitHome = new WebDriverWait(driver, Synctime);	
		//waitHome.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//span[text()='Continue']")))).click();;	
		WebElement HomePageElement = waitHome.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("HOME_PAGE")))));				
		if (HomePageElement.isDisplayed()) {
			System.out.println("Login Successful ");
			report(Status.PASS, "Expected result", "Login is Successful", testId, testCaseId, TestAction, test, steps);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			//return true;
		} else {
			System.out.println("Login not Successful ");
			report(Status.FAIL, "Expected result", "Login is not Successful", testId, testCaseId, TestAction, test, steps);
		}				
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Login is not Successful\n Error Message--->"+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	public PassedFailedSteps IcollectLogin(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{

	try{
		String username = "",password = "";
		System.out.println("Into Login method");
		String input=TestAction.getInputData();
		if(input.toLowerCase().contains("~"))
		{
			username = input.split("~")[0];
			password = input.split("~")[1];
		}else
		{
			username = UpdateEnvDetailInDataSheet.config.getProperty("USERID");
			password = UpdateEnvDetailInDataSheet.config.getProperty("PASSWORD");
		}
		driver.get(UpdateEnvDetailInDataSheet.config.getProperty("ICOLLECTURL"));
		report(Status.PASS, "Expected result", "<b>URL</b> : "+UpdateEnvDetailInDataSheet.config.getProperty("ICOLLECTURL"), testId, testCaseId, TestAction, test, steps);
		//Thread.sleep(5000);
		WebDriverWait wait = new WebDriverWait(driver, Synctime);
		
		/* try {
			driver.navigate().to("javascript:document.getElementById('overridelink').click()");	
		}
		catch (Exception e){
			
		} */
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='btniCollect']"))).click();
		
		WebElement UserIDElement = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("LOGIN_TXT_USERNAME")))));
		//fnHighlightMe(driver,UserIDElement);
		UserIDElement.sendKeys(username);
		//Test.log(Status.PASS, "User ID Entered Successfully");
		//report(Status.PASS, "Expected result", username, testId, testCaseId, TestAction, test, steps);
		
		WebElement PasswordElement = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("LOGIN_TXT_PASSWORD")))));
		//fnHighlightMe(driver,PasswordElement);
		//PasswordElement.sendKeys(new DeCrypto().deCoder(UpdateEnvDetailInDataSheet.config.getProperty("PASSWORD")));
		PasswordElement.sendKeys(password);
		//report(Status.PASS, "Expected result", password, testId, testCaseId, TestAction, test, steps);
						
		//Test.log(Status.PASS, "Password Entered Successfully");
		
		WebElement SignonElement = wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("(//input[@name='btnOK'])[2]"))));	
		//fnHighlightMe(driver,SignonElement);
		SignonElement.click();
		//WebDriverWait wait = new WebDriverWait(driver, 300 /*timeout in seconds*/);
		WebDriverWait waitHome = new WebDriverWait(driver, Synctime);	
		waitHome.until(ExpectedConditions.visibilityOfElementLocated((By.xpath("//span[text()='Continue']")))).click();;	
		WebElement HomePageElement = waitHome.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(UpdateEnvDetailInDataSheet.config.getProperty("IcollectHome_Page")))));				
		if (HomePageElement.isDisplayed()) {
			System.out.println("Login Successful ");
			report(Status.PASS, "Expected result", "Login is Successful", testId, testCaseId, TestAction, test, steps);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			//return true;
		} else {
			System.out.println("Login not Successful ");
			report(Status.FAIL, "Expected result", "Login is not Successful", testId, testCaseId, TestAction, test, steps);
		}				
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Login is not Successful\n Error Message--->"+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
	public WebElement ElementExists(WebDriver driver,int OptSynctime,String Xpathval) throws IOException{		
			WebDriverWait wait = new WebDriverWait(driver,OptSynctime);			
			return wait.until(ExpectedConditions.visibilityOfElementLocated((By.xpath(Xpathval))));
			
			
	}
	public PassedFailedSteps Logout(WebDriver driver, String testId, String testCaseId, TestAction TestAction, ExtentTest test, String steps) throws IOException{

		try{
			WebDriverWait wait = new WebDriverWait(driver,20);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[contains(@id,'Header1_hlLogInOut')]")));
			WebElement we1 = driver.findElement(By.xpath("//a[contains(@id,'Header1_hlLogInOut')]"));
			JavascriptExecutor jse = (JavascriptExecutor) driver;
			jse.executeScript("arguments[0].focus();",we1);
			jse.executeScript("var elem = arguments[0];setTimeout(function(){elem.click();},3000)",we1);
			Thread.sleep(3000);
			report(Status.PASS, "Expected result", "Logout is  Successful", testId, testCaseId, TestAction, test, steps);
		}catch(Exception ey)
		{
			ey.printStackTrace();
			report(Status.FAIL, "Expected result", "Logout is not Successful\n Error Message--->"+ey.getMessage(), testId, testCaseId, TestAction, test, steps);
		}
		return pfSteps;
	}
}
