package com.verizon.cao.automation.selenium.util;

import java.awt.AWTException;
import java.text.ParseException;

import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.verizon.cao.automation.selenium.pojo.DataSheet;
import com.verizon.cao.automation.selenium.pojo.TestAction;


public class CustomizedMethods {

	/**
	 * This is an another way of writing custom methods. Create a switch case for your keyword and write the logic below.
	 * @param driver
	 * @param testSteps
	 * @param testFromDataSheet
	 * @param test
	 * @return
	 * @throws ParseException
	 * @throws InterruptedException
	 * @throws AWTException
	 */ 
	//Checkin test by Kantha
	public Boolean customMethods(WebDriver driver, TestAction testSteps,DataSheet testFromDataSheet,ExtentTest test)
			throws ParseException, InterruptedException, AWTException {
		switch (testSteps.getKeyword()) {
		case "sampleKeyWord":
			sampleKeyWord(driver);
			return true;
		}
		return null;
	}
	
	public void sampleKeyWord(WebDriver driver) throws InterruptedException{
		
	}
}
